rootProject.name = "eureka-client-1"
