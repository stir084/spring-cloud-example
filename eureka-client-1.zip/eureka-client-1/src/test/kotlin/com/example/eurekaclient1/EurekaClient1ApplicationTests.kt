package com.example.eurekaclient1

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class EurekaClient1ApplicationTests {

	@Test
	fun contextLoads() {
	}

}
