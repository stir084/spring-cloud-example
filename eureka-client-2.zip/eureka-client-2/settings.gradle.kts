rootProject.name = "eureka-client-2"
