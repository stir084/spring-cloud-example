package com.example.gatewayserver

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class GatewayServerApplicationTests {

	@Test
	fun contextLoads() {
	}

}
