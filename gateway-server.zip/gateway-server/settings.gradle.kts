rootProject.name = "gateway-server"
